// Example package for Vosk Go bindings.
package main
